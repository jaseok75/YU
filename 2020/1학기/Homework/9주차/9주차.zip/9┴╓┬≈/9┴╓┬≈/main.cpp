﻿#define _CRT_SECURE_NO_WARNINGS

/*
 * 파일명: "Homework09_21912150_김하림_main.cpp"
 * 프로그램의 목적 및 기본 기능:
 * - 이 프로그램은 구조체 Time을 사용하는 Clock system을 만드는 프로그램이다.
 * 
 * 프로그램 작성자: 김하림 (2020년 05월 27일)
 * 최종 Update: 2020년 05월 27일(김하림).
 */
#include <stdio.h>
#include "Time.h"
#define NUM_TIMES 5

void main()
{
	Time t1, t2;
	Time times[NUM_TIMES];
	int incr_secs, diff_sec;

	t1 = t2 = inputTime();	//t1과 t2에 시간 입력받기
	printf("Input time t1 = "); 
	printTime(&t1);	//시간 출력하기
	printf("\n");
	printf("input seconds to increment : ");
	scanf("%d", &incr_secs);	//초 입력받기

	incrementTime(&t2, incr_secs);	//원래 시간에 초 증가하기
	printf("After incrementing %d secs, t2 = ", incr_secs); 
	printTime(&t2);		//증가시킨 초 출력하기
	printf("\n");

	diff_sec = compareTime(&t1, &t2);	//증가시킨 초와 원래 초의 차 구하기
	printf("Difference between t1 and t2 is %d secs\n", diff_sec);

	times[0] = initTime(23, 59, 59);
	times[1] = initTime(9, 0, 5);
	times[2] = initTime(13, 30, 0);
	times[3] = initTime(3, 59, 59);
	times[4] = initTime(0, 0, 0);
	printf("\nBefore sorting times : \n");

	//Sorting 전의 시간 출력하기
	for (int i = 0; i < NUM_TIMES; i++)
	{
		printf("times[%d] = ", i); 
		printTime(&times[i]); 
		printf("\n");
	}

	//시간 작은 순서대로 정렬하기
	selectSortTime(times, NUM_TIMES);
	printf("After selection sorting of times : \n");

	//정렬한 초 출력하기
	for (int i = 0; i < NUM_TIMES; i++)
	{
		printf("times[%d] = ", i); 
		printTime(&times[i]); 
		printf("\n");
	}
}