﻿/*
 * 파일명: "Homework09.cpp"
 * 프로그램의 목적 및 기본 기능:
 * - 복소수 계산을 위한 구조체 정의(Struct Cmplx)
 *
 * 프로그램 작성자: 김하림 (2020년 05월 29일),
 * 최종 Update: 2020년 05월 29일(김하림).
 */
#include <stdio.h>
#include "Cmplx.h"

void main()
{
	Cmplx cmplxs[7];

	cmplxs[0] = inputCmplx();	//cmplxs[0] 입력받기
	cmplxs[1] = inputCmplx();	//cmplxs[1] 입력받기

	printf("cmplxs[0] = "); 
	printCmplx(cmplxs[0]);	//cmplxs[0] 출력하기
	printf("\n");
	printf("cmplxs[1] = "); 
	printCmplx(cmplxs[1]);	//cmplxs[1] 출력하기
	printf("\n");

	// 두 복소수의 덧셈 후 저장하기
	cmplxs[2] = cmplxAdd(cmplxs[0], cmplxs[1]);

	printf("cmplxs[2] = cmplxs[0] + cmplxs[1] = \n ");

	printCmplx(cmplxs[0]);	//cmplxs[0] 출력하기
	printf(" + "); 
	printCmplx(cmplxs[1]);	//cmplxs[1] 출력하기
	printf(" = "); 
	printCmplx(cmplxs[2]);	//cmplxs[2] 출력하기
	printf("\n");

	// 두 복소수의 뺄셈 후 저장하기
	cmplxs[3] = cmplxSub(cmplxs[0], cmplxs[1]);

	printf("cmplxs[3] = cmplxs[0] - cmplxs[1] = \n ");

	printCmplx(cmplxs[0]);	//cmplxs[0] 출력하기
	printf(" - "); 
	printCmplx(cmplxs[1]);	//cmplxs[1] 출력하기
	printf(" = "); 
	printCmplx(cmplxs[3]);	//cmplxs[3] 출력하기
	printf("\n");

	// 두 복소수의 곱셈 후 저장하기
	cmplxs[4] = cmplxMul(cmplxs[0], cmplxs[1]);

	printf("cmplxs[4] = cmplxs[0] * cmplxs[1] = \n ");
	printCmplx(cmplxs[0]);	//cmplxs[0] 출력하기
	printf(" * "); 
	printCmplx(cmplxs[1]);	//cmplxs[1] 출력하기
	printf(" = "); 
	printCmplx(cmplxs[4]);	//cmplxs[4] 출력하기
	printf("\n");

	// 두 복소수의 나눗셈 후 저장하기
	cmplxs[5] = cmplxDiv(cmplxs[0], cmplxs[1]);

	printf("cmplxs[5] = cmplxs[0] / cmplxs[1] = \n ");
	printCmplx(cmplxs[0]);	//cmplxs[0] 출력하기
	printf(" / "); 
	printCmplx(cmplxs[1]);	//cmplxs[1] 출력하기
	printf(" = "); 
	printCmplx(cmplxs[5]);	//cmplxs[5] 출력하기
	printf("\n");

	// 두 복소수의 곱셈 후 저장하기
	cmplxs[6] = cmplxMul(cmplxs[1], cmplxs[5]);

	printf("cmplxs[6] = cmplxs[1] * cmplxs[5] = \n ");
	printCmplx(cmplxs[1]);	//cmplxs[1] 출력하기
	printf(" * "); 
	printCmplx(cmplxs[5]);	//cmplxs[5] 출력하기
	printf(" = ");
	printCmplx(cmplxs[6]);	//cmplxs[6] 출력하기
	printf("\n");

	printf("Before sorting complexs: \n");
	
	//모든 cmplxs 출력하기
	for (int i = 0; i < 7; i++)
	{
		printf("cmplxs[%d] = ", i); 
		printCmplx(cmplxs[i]);
		printf("\n");
	}

	//cmplxs 퀵정렬 방식으로 정렬하기
	quickSortCmplx(cmplxs, 7);
	printf("Sorted complexs: \n");

	// 정렬된 cmplxs 출력하기
	for (int i = 0; i < 7; i++)
	{
		printf("cmplxs[%d] = ", i); 
		printCmplx(cmplxs[i]);
		printf("\n");
	}
}