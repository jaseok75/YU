/* Cmplx.h */
#ifndef CMPLX_H
#define CMPLX_H

typedef struct
{
	double real;
	double imag; // imaginary
} Cmplx;

Cmplx inputCmplx();
void printCmplx(const Cmplx c);
Cmplx cmplxAdd(const Cmplx c1, const Cmplx c2);
Cmplx cmplxSub(const Cmplx c1, const Cmplx c2);
Cmplx cmplxMul(const Cmplx c1, const Cmplx c2);
Cmplx cmplxDiv(const Cmplx c1, const Cmplx c2);
void quickSortCmplx(Cmplx cmplxs[], int size);
void _quickSortCmplx(Cmplx cmplxs[], int size, int left, int right, int level);
double compareCmplx(const Cmplx c1, Cmplx c2);

#endif